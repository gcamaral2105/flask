"""
Middleware Module
================

Middleware components for the ERP Bauxita system.
"""

