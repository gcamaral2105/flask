"""
API Resources Module
===================

API resource endpoints for the ERP Bauxita system.
"""

