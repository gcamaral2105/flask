"""
API Module
==========

API module for the ERP Bauxita system.
"""

