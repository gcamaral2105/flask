"""
Utilities Module
===============

Common utilities for the ERP Bauxita system.
"""

