# ERP Bauxita - Exemplos de Uso da API

Este documento contém exemplos práticos de como usar a API do ERP Bauxita.

## Autenticação

### 1. Login
```bash
curl -X POST http://localhost:5000/api/v1/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "username": "admin",
    "password": "admin123"
  }'
```

**Resposta:**
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9...",
    "user": {
      "id": 1,
      "username": "admin",
      "role": "admin",
      "email": "admin@bauxita-erp.com"
    },
    "expires_in": 3600,
    "token_type": "Bearer"
  }
}
```

### 2. Usar Token nas Requisições
```bash
# Salvar token em variável
TOKEN="eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9..."

# Usar em requisições
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:5000/api/v1/productions
```

## Productions (Produções)

### 1. Listar Produções
```bash
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:5000/api/v1/productions
```

### 2. Criar Nova Produção
```bash
curl -X POST http://localhost:5000/api/v1/productions \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "scenario_name": "Cenário 2025 Q1",
    "scenario_description": "Planejamento para primeiro trimestre de 2025",
    "contractual_year": 2025,
    "total_planned_tonnage": 12000000,
    "start_date_contractual_year": "2025-01-01",
    "end_date_contractual_year": "2025-12-31",
    "standard_moisture_content": 3.00
  }'
```

### 3. Obter Produção Específica
```bash
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:5000/api/v1/productions/1
```

### 4. Ativar Cenário de Produção
```bash
curl -X POST http://localhost:5000/api/v1/productions/1/activate \
  -H "Authorization: Bearer $TOKEN"
```

### 5. Obter Métricas da Produção
```bash
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:5000/api/v1/productions/1/metrics
```

### 6. Dashboard de Produção
```bash
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:5000/api/v1/productions/dashboard?year=2025
```

### 7. Inscrever Parceiro na Produção
```bash
curl -X POST http://localhost:5000/api/v1/productions/1/partners \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "partner_id": 1,
    "vessel_size_t": 180000,
    "minimum_tonnage": 2000000
  }'
```

## Vessels (Embarcações)

### 1. Listar Embarcações
```bash
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:5000/api/v1/vessels
```

### 2. Filtrar por Tipo
```bash
curl -H "Authorization: Bearer $TOKEN" \
  "http://localhost:5000/api/v1/vessels?type=capesize&status=active"
```

### 3. Criar Nova Embarcação
```bash
curl -X POST http://localhost:5000/api/v1/vessels \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "MV Bauxita Express",
    "vtype": "capesize",
    "imo": "1234567",
    "dwt": 180000,
    "loa": 289.5,
    "beam": 45.0,
    "owner_partner_id": 1
  }'
```

### 4. Alterar Status da Embarcação
```bash
curl -X PUT http://localhost:5000/api/v1/vessels/1/status \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "status": "maintenance",
    "reason": "Manutenção preventiva programada"
  }'
```

### 5. Agendar Manutenção
```bash
curl -X POST http://localhost:5000/api/v1/vessels/1/maintenance \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "scheduled_start": "2025-09-01",
    "estimated_duration_days": 14,
    "maintenance_type": "preventive"
  }'
```

### 6. Visão Geral da Frota
```bash
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:5000/api/v1/vessels/fleet/overview
```

### 7. Otimizar Alocação da Frota
```bash
curl -X POST http://localhost:5000/api/v1/vessels/fleet/optimize \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "requirements": {
      "total_capacity": 500000,
      "preferred_types": ["capesize", "panamax"],
      "time_window": "2025-Q1"
    }
  }'
```

### 8. Buscar por IMO
```bash
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:5000/api/v1/vessels/by-imo/1234567
```

## Partners (Parceiros)

### 1. Listar Parceiros
```bash
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:5000/api/v1/partners
```

### 2. Filtrar Compradores HALCO
```bash
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:5000/api/v1/partners/halco-buyers
```

### 3. Criar Novo Parceiro
```bash
curl -X POST http://localhost:5000/api/v1/partners \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Nova Empresa Ltda",
    "entity": {
      "entity_type": "OFFTAKER",
      "contact_email": "contato@novaempresa.com",
      "country": "Brasil"
    }
  }'
```

### 4. Portfolio do Parceiro
```bash
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:5000/api/v1/partners/1/portfolio
```

### 5. Avaliação de Performance
```bash
curl -H "Authorization: Bearer $TOKEN" \
  "http://localhost:5000/api/v1/partners/1/performance?period_days=365"
```

### 6. Embarcações do Parceiro
```bash
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:5000/api/v1/partners/1/vessels
```

### 7. Recomendações de Parceiros
```bash
curl -X POST http://localhost:5000/api/v1/partners/recommendations \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "requirements": {
      "vessel_capacity": 180000,
      "entity_type": "HALCO",
      "region": "Atlantic"
    }
  }'
```

## Exemplos com Python

### 1. Cliente Python Básico
```python
import requests
import json

class BauxitaERPClient:
    def __init__(self, base_url="http://localhost:5000"):
        self.base_url = base_url
        self.token = None
    
    def login(self, username, password):
        """Fazer login e obter token."""
        response = requests.post(
            f"{self.base_url}/api/v1/auth/login",
            json={"username": username, "password": password}
        )
        if response.status_code == 200:
            data = response.json()
            self.token = data["data"]["token"]
            return True
        return False
    
    def get_headers(self):
        """Obter headers com autenticação."""
        return {"Authorization": f"Bearer {self.token}"}
    
    def get_productions(self):
        """Listar produções."""
        response = requests.get(
            f"{self.base_url}/api/v1/productions",
            headers=self.get_headers()
        )
        return response.json()
    
    def create_production(self, data):
        """Criar nova produção."""
        response = requests.post(
            f"{self.base_url}/api/v1/productions",
            headers=self.get_headers(),
            json=data
        )
        return response.json()

# Uso
client = BauxitaERPClient()
client.login("admin", "admin123")

# Listar produções
productions = client.get_productions()
print(json.dumps(productions, indent=2))

# Criar nova produção
new_production = {
    "scenario_name": "Teste API",
    "contractual_year": 2025,
    "total_planned_tonnage": 10000000,
    "start_date_contractual_year": "2025-01-01",
    "end_date_contractual_year": "2025-12-31"
}
result = client.create_production(new_production)
print(json.dumps(result, indent=2))
```

### 2. Exemplo com Requests Session
```python
import requests

# Criar sessão
session = requests.Session()

# Login
login_response = session.post(
    "http://localhost:5000/api/v1/auth/login",
    json={"username": "admin", "password": "admin123"}
)
token = login_response.json()["data"]["token"]

# Configurar header de autorização para todas as requisições
session.headers.update({"Authorization": f"Bearer {token}"})

# Usar a sessão para fazer requisições
productions = session.get("http://localhost:5000/api/v1/productions").json()
vessels = session.get("http://localhost:5000/api/v1/vessels").json()
partners = session.get("http://localhost:5000/api/v1/partners").json()

print(f"Produções: {len(productions['data']['productions'])}")
print(f"Embarcações: {len(vessels['data']['vessels'])}")
print(f"Parceiros: {len(partners['data']['partners'])}")
```

## Tratamento de Erros

### 1. Erro de Autenticação
```bash
curl http://localhost:5000/api/v1/productions
```

**Resposta:**
```json
{
  "success": false,
  "message": "Authentication required",
  "error": {
    "code": 401,
    "type": "Unauthorized",
    "description": "Valid authentication token required"
  },
  "timestamp": "2025-08-14T14:30:00.000Z"
}
```

### 2. Erro de Validação
```bash
curl -X POST http://localhost:5000/api/v1/productions \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "scenario_name": "Teste"
  }'
```

**Resposta:**
```json
{
  "success": false,
  "message": "Validation Error",
  "error": {
    "code": 400,
    "type": "ValueError",
    "description": "Missing required fields: contractual_year, total_planned_tonnage, start_date_contractual_year, end_date_contractual_year"
  },
  "timestamp": "2025-08-14T14:30:00.000Z"
}
```

### 3. Recurso Não Encontrado
```bash
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:5000/api/v1/productions/999
```

**Resposta:**
```json
{
  "success": false,
  "message": "Production not found",
  "error": {
    "code": 404,
    "type": "NotFound",
    "description": "The requested resource was not found"
  },
  "timestamp": "2025-08-14T14:30:00.000Z"
}
```

## Paginação

### 1. Listar com Paginação
```bash
curl -H "Authorization: Bearer $TOKEN" \
  "http://localhost:5000/api/v1/productions?page=1&per_page=10"
```

**Resposta:**
```json
{
  "success": true,
  "message": "Productions retrieved successfully",
  "data": {
    "productions": [...],
    "pagination": {
      "page": 1,
      "per_page": 10,
      "total_pages": 5,
      "total_items": 47,
      "has_prev": false,
      "has_next": true,
      "prev_page": null,
      "next_page": 2
    }
  }
}
```

## Filtros Avançados

### 1. Filtros Múltiplos
```bash
# Embarcações ativas do tipo capesize com DWT entre 150000 e 200000
curl -H "Authorization: Bearer $TOKEN" \
  "http://localhost:5000/api/v1/vessels?status=active&type=capesize&min_dwt=150000&max_dwt=200000"
```

### 2. Busca por Texto
```bash
# Buscar produções por nome
curl -H "Authorization: Bearer $TOKEN" \
  "http://localhost:5000/api/v1/productions/search?q=2025"
```

### 3. Filtros por Data
```bash
# Produções de um ano específico
curl -H "Authorization: Bearer $TOKEN" \
  "http://localhost:5000/api/v1/productions?year=2025"
```

## Health Checks

### 1. Status da Autenticação
```bash
curl http://localhost:5000/api/v1/auth/health
```

### 2. Status Geral
```bash
curl http://localhost:5000/
```

---

**Nota:** Todos os exemplos assumem que o servidor está rodando em `http://localhost:5000`. Ajuste a URL conforme necessário para seu ambiente.

